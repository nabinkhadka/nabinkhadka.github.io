**************************
### FRESH INSTALLATION ###
**************************
```
$ sudo su
$ export SECRET=XXXXXXXXXXXX # PROVIDED BY JSL
$ ./annotationlab-installer.sh
```
The last command will generate some commands which can be executed to get secrets of the installation.

Copy the output to a file for future use.

Use `admin` username and get password using one of the commands from above output.



***********************
### UPGRADE VERSION ###
***********************
```
$ sudo su
$ export SECRET=XXXXXXXXXXXX # PROVIDED BY JSL
$ ./annotationlab-updater.sh
```
