#!/usr/bin/env bash
set -euo pipefail

curl -sfL https://get.k3s.io | INSTALL_K3S_VERSION=v1.18.12+k3s1 sh 
