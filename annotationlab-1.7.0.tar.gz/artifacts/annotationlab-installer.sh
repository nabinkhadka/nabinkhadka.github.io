#!/usr/bin/env bash
set -euo pipefail

if [ ! -f annotationlab-*.tgz ]; then
    echo "Please make sure there is a annotationlab-*.tgz helm chart package in the same directory as this installer."
    exit 1
fi
if [[ -z ${SECRET} ]]; then
    echo "Please provide container registry secret"
    exit 1
fi

ANNOTATIONLAB_VERSION=$(ls annotationlab-*.tgz | sed 's/annotationlab-\(.*\).tgz/\1/')

kubectl get nodes

HELM_VER=v3.3.1

curl -s -L https://get.helm.sh/helm-${HELM_VER}-linux-amd64.tar.gz -o- | tar -C /usr/local/bin/ -x linux-amd64/helm -zf- --strip-components=1

IMAGES="${ANNOTATIONLAB_VERSION} active-learning-${ANNOTATIONLAB_VERSION} dataflows-${ANNOTATIONLAB_VERSION} auth-theme-${ANNOTATIONLAB_VERSION}"
for image in $IMAGES; do
    crictl pull --auth ${SECRET} johnsnowlabs/annotationlab:${image};
done

uuid_gen_string="\$(openssl rand -hex 4)-\$(openssl rand -hex 2)-\$(openssl rand -hex 2)-\$(openssl rand -hex 2)-\$(openssl rand -hex 6)"
password_gen_string="\$(openssl rand -hex 10)"

helm install annotationlab annotationlab-${ANNOTATIONLAB_VERSION}.tgz                \
    --kubeconfig /etc/rancher/k3s/k3s.yaml                                                \
    --set image.tag=${ANNOTATIONLAB_VERSION}                                              \
    --set ingress.enabled=true                                                            \
    --set ingress.defaultBackend=true                                                     \
    --set 'ingress.hosts[0].host=domain.tld'                                              \
    --set airflow.redis.password=$(bash -c "echo ${password_gen_string}")                 \
    --set configuration.FLASK_SECRET_KEY=$(bash -c "echo ${password_gen_string}")         \
    --set configuration.KEYCLOAK_CLIENT_SECRET_KEY=$(bash -c "echo ${uuid_gen_string}")   \
    --set postgresql.postgresqlPassword=$(bash -c "echo ${password_gen_string}")          \
    --set keycloak.postgresql.postgresqlPassword=$(bash -c "echo ${password_gen_string}") \
    --set keycloak.secrets.admincreds.stringData.user=admin                               \
    --set keycloak.secrets.admincreds.stringData.password=$(bash -c "echo ${password_gen_string}")

